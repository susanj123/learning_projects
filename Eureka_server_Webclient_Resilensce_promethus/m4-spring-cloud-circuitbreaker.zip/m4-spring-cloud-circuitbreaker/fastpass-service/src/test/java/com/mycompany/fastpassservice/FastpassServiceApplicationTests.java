package com.mycompany.fastpassservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastpassServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
