package com.mycompany.tollrateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TollrateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
