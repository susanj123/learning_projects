package com.mycompany.tollrateservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TollrateServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TollrateServiceApplication.class, args);
	}

}
