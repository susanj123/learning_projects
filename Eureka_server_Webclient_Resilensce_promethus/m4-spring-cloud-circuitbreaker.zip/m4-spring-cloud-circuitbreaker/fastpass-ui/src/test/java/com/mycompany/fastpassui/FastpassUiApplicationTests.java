package com.mycompany.fastpassui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastpassUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
